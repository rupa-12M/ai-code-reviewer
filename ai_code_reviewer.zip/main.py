from fastapi import FastAPI
import openai
import faiss
import numpy as np

app = FastAPI()

# Replace with your OpenAI API Key
openai.api_key = "YOUR_OPENAI_API_KEY"

# Initialize FAISS Index
dim = 1536  # OpenAI embedding dimension
index = faiss.IndexFlatL2(dim)

# Dictionary to store uploaded code snippets
code_snippets = {}

# Function to generate embeddings
def generate_embedding(text):
    response = openai.Embedding.create(input=[text], model="text-embedding-ada-002")
    return np.array(response["data"][0]["embedding"])

# Upload code snippet and store in FAISS
@app.post("/upload_code/")
def upload_code(code: str):
    embedding = generate_embedding(code)
    idx = len(code_snippets)
    index.add(np.array([embedding]).astype('float32'))
    code_snippets[idx] = {"code": code}
    return {"message": f"Code uploaded with ID {idx}"}

# Review code using OpenAI GPT
@app.post("/review_code/")
def review_code(code: str):
    prompt = f"Analyze the following code for bugs, inefficiencies, and security issues. Suggest improvements:

{code}"
    response = openai.ChatCompletion.create(
        model="gpt-4",
        messages=[{"role": "user", "content": prompt}]
    )
    return {"review": response["choices"][0]["message"]["content"]}

# Find similar code snippets
@app.post("/find_similar_code/")
def find_similar_code(code: str):
    code_embedding = generate_embedding(code)
    _, idxs = index.search(np.array([code_embedding]).astype('float32'), 3)
    matched_codes = [code_snippets[idx]["code"] for idx in idxs[0] if idx in code_snippets]
    return {"similar_codes": matched_codes}
